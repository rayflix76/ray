#!/usr/bin/python3
# creation initial par osmoze06 le 09 10 21
# modifié par rayflix le 23 10 21
import xbmc
import xbmcaddon
from io import BytesIO
from urllib.request import urlopen
from zipfile import ZipFile
import os
import shutil
import sys

xbmc.executebuiltin("Notification(OPTION DE VSTREAM,Effacement en cours...)")

# suppression du setting de vstream
# nous devrions vérifier si le fichier existe ou non avant de le supprimer.
if os.path.isfile(xbmc.translatePath('special://home/userdata/addon_data/plugin.video.vstream/settings.xml')):
    os.remove(xbmc.translatePath('special://home/userdata/addon_data/plugin.video.vstream/settings.xml'))
else:
    print("Impossible de supprimer le fichier car il n'existe pas")
xbmc.sleep(2000)

xbmc.executebuiltin("Notification(COMPTE 7,Téléchargement en cours...)")

# telechargement et extraction du zip
zipurl = 'https://github.com/rayflix76/pack/raw/kodi/cpt_ray7.zip'
with urlopen(zipurl) as zipresp:
    with ZipFile(BytesIO(zipresp.read())) as zfile:
        zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))

# copie des fichiers extraie
source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)

# config u2play
addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
keyUpto = "24c80f5c228537908144272593d62342570mv"
addon.setSetting(id="keyupto", value=keyUpto)
nb_items = "50"
addon.setSetting(id="nb_items", value=nb_items)
thumbnails = "5000"
addon.setSetting(id="thumbnails", value=thumbnails)

# config vstream
addon = xbmcaddon.Addon("plugin.video.vstream")
addon.setSetting(id="hoster_uptobox_token", value=keyUpto)

#config catchup
addon = xbmcaddon.Addon("plugin.video.catchuptvandmore")
mail = "rayflix@laposte.net"
mot2passe = "Mot2passe"
addon.setSetting(id="nrj.login", value=mail)
addon.setSetting(id="6play.login", value=mail)
addon.setSetting(id="rmcbfmplay.login", value=mail)
addon.setSetting(id="nrj.password", value=mot2passe)
addon.setSetting(id="6play.password", value=mot2passe)
addon.setSetting(id="rmcbfmplay.password", value=mot2passe)

xbmc.executebuiltin("Notification(EXTRACTION OK,Mise à jour effectuée !)")
xbmc.sleep(2000)
xbmc.executebuiltin("Notification(VOUS POUVEZ CHOISIR UN SKIN,Attention les skin full sont plus gourmand !)")

sys.exit()