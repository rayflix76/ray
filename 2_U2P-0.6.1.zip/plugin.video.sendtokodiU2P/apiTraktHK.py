import sys, os
import json
import requests
import datetime
import time
import io
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import widget

ADDON = xbmcaddon.Addon("plugin.video.sendtokodiU2P")

class ApiTrakt:

    def __init__(self, **kwargs):
        self.client_id = ""
        self.client_secret = ""
        self.access_token = ""
        self.refresh_token = ""
        self.pincode = ""
        self.baseurl = 'https://api.trakt.tv'
        self.config_parser = ''
        self.config_path = ""
        self.keyExpire = "0"
        self.dictUsers = {}
        self.tabmedia = []

        for attr_name, attr_value in kwargs.items():
            setattr(self, attr_name, attr_value)

        if self.client_id and self.client_secret:
            if self.keyExpire:
                if ((int(self.keyExpire) - time.time()) < 0 and self.refresh_token):
                    self.refreshToken()

        self.headers = {
                'Accept'            : 'application/json',   # required per API
                'Content-Type'      : 'application/json',   # required per API
                'User-Agent'        : 'Tratk importer',     # User-agent
                'Connection'        : 'Keep-Alive',         # Thanks to urllib3, keep-alive is 100% automatic within a session!
                'trakt-api-version' : '2',                  # required per API
                'trakt-api-key'     : self.client_id,                   # required per API
                'Authorization'     : 'Bearer %s' %self.access_token,                   # required per API
            }


    def refreshToken(self):
        url = self.baseurl + '/oauth/token'
        values = {
                "refresh_token": self.refresh_token,
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "redirect_uri": "urn:ietf:wg:oauth:2.0:oob",
                "grant_type": "refresh_token"
            }
        request = requests.post(url, data=values)
        response = request.json()
        self.access_token = response["access_token"]
        self.refresh_token = response['refresh_token']
        self.keyExpire =  int(response["created_at"]) + int(response["expires_in"])

    def getUserlists(self, userlist, page=1):
        self.dictUsers = {}
        url = self.baseurl + '/users/{user}/lists'.format(
                            user=userlist, page=page, limit=1000)
        r = requests.get(url, headers=self.headers, timeout=(5, 60))
        listes = json.loads(r.text)
        self.dictUsers[userlist] = {liste["ids"]["slug"]: (liste["ids"]["trakt"], liste["name"], liste['item_count'], liste["user"]["ids"]["slug"], liste["user"]["username"]) for liste in listes}
        return self.dictUsers

    def getUserListsLight(self, userlist, page=1):
        self.dictUsers = {}
        url = self.baseurl + '/users/{user}/lists'.format(
                            user=userlist, page=page, limit=1000)
        r = requests.get(url, headers=self.headers, timeout=(5, 60))
        try:
            listes = json.loads(r.text)
            self.dictUsers[userlist] = {liste["name"]: (liste["user"]["ids"]["slug"], liste["ids"]["slug"], liste["name"], liste['item_count']) for liste in listes}
        except:
            self.dictUsers = {}
        return self.dictUsers

    def getList(self, userlist, numList, nomList, typMedia="movies", page=1):
        url = self.baseurl + '/users/{user}/lists/{list_id}/items/{type}?page={page}&limit={limit}'.format(
                            user=userlist, list_id=numList, type=typMedia, page=page, limit=1000)
        r = requests.get(url, headers=self.headers, timeout=(5, 60))
        listeMedias = json.loads(r.text)
        for media in listeMedias:
            typ = media["type"]
            self.tabmedia.append(media[typ]["ids"]['tmdb'])
        if 'X-Pagination-Page-Count' in r.headers and r.headers['X-Pagination-Page-Count']:
            print("Recup page {page} of {PageCount} pages for num {list} list".format(
                    page=page, PageCount=r.headers['X-Pagination-Page-Count'], list=numList))
            if page != int(r.headers['X-Pagination-Page-Count']):
                getList(userlist, numList, nomList, typMedia=typMedia, page=page + 1)

    def getListId(self, numList):
        url = self.baseurl + '/lists/{list_id}/items'.format(
                            list_id=numList)
        r = requests.get(url, headers=self.headers, timeout=(5, 60))
        listeMedias = json.loads(r.text)
        return listeMedias

    def extractList(self, user, nomList, typMedia="movies"):
        self.getUserlists(user)
        self.tabmedia = []
        try:
            self.getList(user, self.dictUsers[user][nomList][0], self.dictUsers[user][nomList][1], typMedia)
        except Exception as e:
            print("err", e)
            print("liste User")
            print(self.dictUsers[user])
        return self.tabmedia

    def extractListsUser(self, name):
        listsUser = []
        user = self.getUserlists(name)
        for nom, listes in user.items():
            for nomListe, liste in listes.items():
                username, name, num = liste[-1], liste[1], liste[0]
                medias = self.getListId(num)
                tabTMDB = []
                for media in medias:
                    typ = media["type"]
                    tabTMDB.append(media[typ]["ids"]["tmdb"])
                listsUser.append((username, typ, name, tabTMDB))
        return listsUser

    def getToken(self):
        values = {
            "client_id": self.client_id
                 }
        headers = {
            'Content-Type'      : 'application/json'
                }

        url = self.baseurl + '/oauth/device/code'
        request = requests.post(url, data=json.dumps(values), headers=headers)
        r = request.json()
        return r["device_code"], r["user_code"], r["verification_url"]

    def getToken2(self, device_code):
        headers = {
            'Content-Type'      : 'application/json'
        }

        values = {
            "code": device_code,
            "client_id": self.client_id,
            "client_secret": self.client_secret
                }

        url = self.baseurl + '/oauth/device/token'
        request = requests.post(url, data=json.dumps(values), headers=headers)
        r = request.json()
        return r
def showInfoNotification(message):
    xbmcgui.Dialog().notification("U2Pplay", message, xbmcgui.NOTIFICATION_INFO, 5000)

class TraktHK(ApiTrakt):
    
    def __init__(self):
        cfg = {
            "client_id": ADDON.getSetting("clientid"),
            "client_secret": ADDON.getSetting("clientsecret"),
            "access_token": ADDON.getSetting("clientacces"),
            "refresh_token": ADDON.getSetting("clientrefresh"),
            "keyExpire": ADDON.getSetting("clientexpire"),
            }
        ApiTrakt.__init__(self, **cfg)
        if not cfg["access_token"]:
            device, code, url = self.getToken()     
            if device:
                dialog = xbmcgui.Dialog()
                ok = dialog.yesno('Validation device Trakt', "Valides le code %s\nsur la page %s\nQuand c'est fait, click sur OUI" %(code, url))
                if ok:
                    response = self.getToken2(device)
                    access_token = response["access_token"]
                    refresh_token = response['refresh_token']
                    keyExpire = int(response["created_at"]) + int(response["expires_in"])
                    ADDON.setSetting("clientacces", access_token)
                    ADDON.setSetting("clientrefresh", refresh_token)
                    ADDON.setSetting("clientexpire", str(keyExpire))
                else:
                    return
        else:
            ADDON.setSetting("clientacces", self.access_token)
            ADDON.setSetting("clientrefresh", self.refresh_token)
            ADDON.setSetting("clientexpire", str(self.keyExpire))

    def importListes(self, typM="movie"):
        dialog = xbmcgui.Dialog()
        d = dialog.input("User Trakt (exemple: alKODIque):", type=xbmcgui.INPUT_ALPHANUM)
        if d:
            dictListes = self. getUserListsLight(d)
            if dictListes:
                choix = list(dictListes[d].keys())
                dialog = xbmcgui.Dialog()
                chListes = dialog.multiselect("Selectionner la/les liste(s) à importer", choix, preselect=[])
                if chListes:
                    tabListe = [dictListes[d][x] for i, x in enumerate(choix) if i in chListes]
                    listeRep = list(widget.getListesT("movie"))
                    listeGroupes = ["Nouveau"] + list(set([x[3] for x in listeRep]))
                    dialog = xbmcgui.Dialog()
                    ret = dialog.select("Insérer dans le groupe: ", listeGroupes)
                    if ret != -1:
                        if ret == 0:
                            d = dialog.input("Nom du Groupe", type=xbmcgui.INPUT_ALPHANUM)
                            if d:
                                groupe = d
                            else:
                                return
                        else:
                            groupe = listeGroupes[ret]
                        [widget.insertTrakt(*(x[0], x[1], typM, groupe, x[2])) for x in tabListe]
                        showInfoNotification("Création listes ok!!")


        



        