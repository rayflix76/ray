# Module: default
# Author: Rayflix
# Created on: 19.01.2022
import xbmcplugin
from urllib.parse import quote_plus, unquote_plus, parse_qsl
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
from io import BytesIO
from urllib.request import urlopen
from zipfile import ZipFile
import os
import shutil
import requests
import random
import re

artworkPath = xbmcvfs.translatePath('special://home/addons/plugin.program.preniumuptobox/resources/media/')
fanart = artworkPath + "fanart.jpg"

def notice(content):
    log(content, xbmc.LOGINFO)

def log(msg, level=xbmc.LOGINFO):
    addon = xbmcaddon.Addon()
    addonID = addon.getAddonInfo('id')
    xbmc.log('%s: %s' % (addonID, msg), level)

def showErrorNotification(message):
    xbmcgui.Dialog().notification("UptoRay", message,
                                  xbmcgui.NOTIFICATION_ERROR, 5000)
def showInfoNotification(message):
    xbmcgui.Dialog().notification("UptoRay", message, xbmcgui.NOTIFICATION_INFO, 15000)

def add_dir(name, mode, thumb):
    u = sys.argv[0] + "?" + "action=" + str(mode)
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': thumb})
    liz.setProperty("fanart_image", fanart)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def main_menu():
	xbmcplugin.setPluginCategory(__handle__, "Choix UptoRay")
	xbmcplugin.setContent(__handle__, 'files')
	add_dir("[COLOR red]METTRE A JOUR L'ADDON [/COLOR]", 'addon_maj', artworkPath + 'icone.png')
	add_dir("[COLOR deepskyblue]COMPTES PREMIUM ALEATOIRE CLIC ICI[/COLOR]", 'menuKey', artworkPath + 'icone.png')
	add_dir("SELECTIONNER SKIN AU CHOIX", 'menuKey', artworkPath + 'icone.png')
	add_dir("[COLOR red]u2Play[/COLOR] SKIN LIGHT [COLOR deepskyblue](le + leger)[/COLOR]", 'choixskinlite', artworkPath + 'icone.png')
	add_dir("[COLOR red]u2Play[/COLOR] SKIN FULL [COLOR deepskyblue](le + gourmand)[/COLOR]", 'choixskinfull', artworkPath + 'icone.png')
	add_dir("[COLOR red]u2Play[/COLOR] SKIN KIDS [COLOR deepskyblue](special enfants)[/COLOR]", 'choixskinkids', artworkPath + 'icone.png')
	add_dir("[COLOR green]vStream[/COLOR] SKIN LIGHT [COLOR deepskyblue](le + leger)[/COLOR]", 'choixskinlitev', artworkPath + 'icone.png')
	add_dir("[COLOR green]vStream[/COLOR] SKIN FULL [COLOR deepskyblue](le + gourmand)[/COLOR]", 'choixskinfullv', artworkPath + 'icone.png')
	add_dir("[COLOR green]vStream[/COLOR] SKIN KIDS [COLOR deepskyblue](special enfants)[/COLOR]", 'choixskinkidsv', artworkPath + 'icone.png')
	add_dir("[COLOR deepskyblue]NETTOYER KODI : [/COLOR]vide le cache efface les thumbnails et les packages", 'vider_cache', artworkPath + 'icone.png')
	xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)
    
def menuKey():
    tabkey = extractAnotpad()
    nb = 0
    ok = False
    while tabkey:
        keyUpto = random.choice(tabkey)
        status, validite = testUptobox(keyUpto)
        if status == "Success":
            showInfoNotification("Notification(Key Upto ok! expire: %s)" %validite)
            ok = True
            break
        else:
            tabkey.remove(keyUpto)
            showErrorNotification("Prevenir Ray key: %s HS" %keyUpto)
            nb += 1
        if nb > 50:
            break
            return
    if ok:
        # config u2play
        try:
            addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
            addon.setSetting(id="keyupto", value=keyUpto)
            nb_items = "50"
            addon.setSetting(id="nb_items", value=nb_items)
            thumbnails = "5000"
            addon.setSetting(id="thumbnails", value=thumbnails)
        except Exception as e:
            notice("Erreur HK: " + str(e))
        
        # config vstream
        try:
            addon = xbmcaddon.Addon("plugin.video.vstream")
            addon.setSetting(id="hoster_uptobox_token", value=keyUpto)
        except Exception as e:
            notice("Erreur Vstream: " + str(e))
        
        #config catchup
        try:
            addon = xbmcaddon.Addon("plugin.video.catchuptvandmore")
            mail = "rayflix@laposte.net"
            mot2passe = "Mot2passe"
            addon.setSetting(id="nrj.login", value=mail)
            addon.setSetting(id="6play.login", value=mail)
            addon.setSetting(id="rmcbfmplay.login", value=mail)
            addon.setSetting(id="nrj.password", value=mot2passe)
            addon.setSetting(id="6play.password", value=mot2passe)
            addon.setSetting(id="rmcbfmplay.password", value=mot2passe)
        except Exception as e:
            notice("Erreur CatchUp: " + str(e))

        showInfoNotification("Config Comptes ok")
            
def importskinlite():
    # telechargement et extraction du zip
    zipurl = 'https://github.com/rayflix76/pack/raw/kodi/full_films.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))

    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(U2PLAY LIGHT OK,Mise à jour effectuée !)")
    xbmc.sleep(2000)

def importskinfull():
    # telechargement et extraction du zip
    zipurl = 'https://github.com/rayflix76/pack/raw/kodi/light_series.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))

    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(U2PLAY FULL OK,Mise à jour effectuée !)")
    xbmc.sleep(2000)

def importskinkids():
    # telechargement et extraction du zip
    zipurl = 'https://github.com/rayflix76/pack/raw/kodi/light_films.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))

    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(U2PLAY KIDS OK,Mise à jour effectuée !)")
    xbmc.sleep(2000)

def importskinlitev():
    # telechargement et extraction du zip
    zipurl = 'https://github.com/rayflix76/pack/raw/kodi/light_light.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))

    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(VSTREAM LIGHT OK,Mise à jour effectuée !)")
    xbmc.sleep(2000)

def importskinfullv():
    # telechargement et extraction du zip
    zipurl = 'https://github.com/rayflix76/pack/raw/kodi/full_perso.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))

    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(VSTREAM FULL,Mise à jour effectuée !)")
    xbmc.sleep(2000)

def importskinkidsv():
    # telechargement et extraction du zip
    zipurl = 'https://github.com/rayflix76/pack/raw/kodi/light_kids.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))

    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(VSTREAM KIDS,Mise à jour effectuée !)")
    xbmc.sleep(2000)

def addon_maj():
    # telechargement et extraction du zip
    zipurl = 'https://github.com/rayflix76/pack/raw/kodi/addon_maj.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))

    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(EXTRACTION OK,Mise à jour effectuée !)")
    xbmc.sleep(2000)

def vider_cache():
	xbmc.executebuiltin("Notification(FICHIER TEMP,Effacement en cours...)")

	# suppression dossier temporaire
	dirPath = xbmc.translatePath('special://home/temp/temp/')
	try:
	   shutil.rmtree(dirPath)
	except:
	   print('Error while deleting directory')
	xbmc.sleep(1000)
	xbmc.executebuiltin("Notification(DOSSIER PACKAGES,Effacement en cours...)")

	# suppression dossier packages
	dirPath = xbmc.translatePath('special://home/addons/packages/')
	try:
	   shutil.rmtree(dirPath)
	except:
	   print('Error while deleting directory')
	xbmc.sleep(1000)
	xbmc.executebuiltin("Notification(DOSSIER THUMBNAILS,Effacement en cours...)")

	# suppression dossier thumbnails
	dirPath = xbmc.translatePath('special://home/userdata/Thumbnails/')
	try:
	   shutil.rmtree(dirPath)
	except:
	   print('Error while deleting directory')
	xbmc.sleep(1000)
	xbmc.executebuiltin("Notification(CACHE TEMP,Effacement en cours...)")

	# suppression dossier cache
	dirPath = xbmc.translatePath('special://home/cache/temp/')
	try:
	   shutil.rmtree(dirPath)
	except:
	   print('Error while deleting directory')
	xbmc.sleep(1000)

	# actualisation du skin
	xbmc.executebuiltin("Notification(ACTUALISATION , Patientez...)")
	xbmc.sleep(2000)
	xbmc.executebuiltin('ReloadSkin')

def extractAnotpad():
    numAnotepad = __addon__.getSetting("numAnotepad")
    motifAnotepad = r'.*<\s*div\s*class\s*=\s*"\s*plaintext\s*"\s*>(?P<txAnote>.+?)</div>.*'
    url = "https://anotepad.com/note/read/" + numAnotepad.strip()
    rec = requests.get(url)
    r = re.match(motifAnotepad, rec.text, re.MULTILINE|re.DOTALL)
    tabKey = [x.strip() for x in r.group("txAnote").splitlines() if x]
    return tabKey 

def testUptobox(key):
    url = 'https://uptobox.com/api/user/me?token=' + key
    headers = {'Accept': 'application/json'}
    try:
        data = requests.get(url, headers=headers).json()
        status = data["message"]
        validite = data["data"]["premium_expire"]
    except:
        status = "out"
        validite = ""
    return status, validite 

def router(paramstring):
    params = dict(parse_qsl(paramstring))    
    dictActions = {
        #key uptobox
        'menuKey':(menuKey, ""),
        #skin
        'choixskinlite': (importskinlite, ""),
        'choixskinfull': (importskinfull, ""),
        'choixskinkids': (importskinkids, ""),
        'choixskinlitev': (importskinlitev, ""),
        'choixskinfullv': (importskinfullv, ""),
        'choixskinkidsv': (importskinkidsv, ""),
        'addon_maj': (addon_maj, ""),
        'vider_cache': (vider_cache, ""),
        }

    if params:
        fn = params['action']
        if fn in dictActions.keys():
            argv = dictActions[fn][1]
            if argv:
                dictActions[fn][0](argv)
            else:
                dictActions[fn][0]()
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
         main_menu()

if __name__ == '__main__':
    __addon__ = xbmcaddon.Addon("plugin.program.preniumuptobox")
    __handle__ = int(sys.argv[1])
    router(sys.argv[2][1:])
